package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class prodservice {
	
	@Autowired
    private prodservice prodervice;
	private prodservice prodservice;

    public prodservice(prodservice prodservice) {

        this.prodservice =prodservice;
    }

    @GetMapping(path = "/accounts/{accountNumber}")
    public product getAccount(@PathVariable("accountNumber") String accountNumber) {
        return prodservice.getAccount(accountNumber);
    }

	public static product getproduct(String product_name) {
		// TODO Auto-generated method stub
		return null;
	}


}
