package com.example.demo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity 
@Table(name="quantity")
public class Quantity{
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="item_id")      
	private int item_id;
	
	@Column(name="item_rem")	
	private int item_rem;
	
	@Column(name="item_sold")
	private int item_sold;

	public int getItem_id() {
		return item_id;
	}

	public void setItem_id(int item_id) {
		this.item_id = item_id;
	}

	public int getItem_rem() {
		return item_rem;
	}

	public void setItem_rem(int item_rem) {
		this.item_rem = item_rem;
	}

	public int getItem_sold() {
		return item_sold;
	}

	public void setItem_sold(int item_sold) {
		this.item_sold = item_sold;
	}

	
	
}

