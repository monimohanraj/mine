package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ProdController {
	
	@Autowired
    private prodservice prodervice;
	private prodservice prodservice;

    public ProdController(prodservice prodservice) {

        this.prodservice = prodservice;
    }

    @GetMapping(path = "/accounts/{accountNumber}")
    public product getproduct(@PathVariable("product_name") String product_name) {
        return prodservice.getproduct(product_name);
    }


}
