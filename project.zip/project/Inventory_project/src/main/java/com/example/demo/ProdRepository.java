
package com.example.demo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface ProdRepository  extends JpaRepository<product, Integer> {

    @Query("select a from Account a where a.account_num = ?1")
    public product findAccount(String prod_name);

}
